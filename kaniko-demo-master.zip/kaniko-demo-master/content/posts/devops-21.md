---
title: "The DevOps 2.1 Toolkit"
date: 2017-09-21T15:12:25+02:00
draft: false
---

### Building, testing, deploying, and monitoring services inside Docker Swarm clusters

**This book is based on very old technology and the code behind it is not maintained anymore.**
