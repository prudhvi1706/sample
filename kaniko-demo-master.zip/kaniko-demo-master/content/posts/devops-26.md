---
title: "The DevOps 2.6 Toolkit"
date: 2018-11-09T01:24:49+02:00
draft: false
---

## Jenkins X

### Cloud-Native Kubernetes-First Continuous Delivery

This book was removed from sales and the repository with the manuscript ([vfarcic/devops26](https://github.com/vfarcic/devops26)) has been donated to the community.
