---
title: "The DevOps 2.2 Toolkit"
date: 2017-09-21T15:17:10+02:00
draft: false
---

### Building Self-Adaptive And Self-Healing Docker Clusters

**This book is based on very old technology and the code behind it is not maintained anymore.**
