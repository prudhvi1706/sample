---
title: "The DevOps 2.4 Toolkit"
date: 2018-08-23T01:24:49+02:00
draft: false
image: devops24-smaller.png
---

## Continuous Deployment To Kubernetes

This book was removed from sales and the repository with the manuscript ([vfarcic/devops24](https://github.com/vfarcic/devops24)) has been donated to the community.
