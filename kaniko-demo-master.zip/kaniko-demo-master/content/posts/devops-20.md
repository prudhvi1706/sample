---
title: "The DevOps 2.0 Toolkit"
date: 2017-09-21T13:31:31+02:00
draft: false
---

### Automating the Continuous Deployment Pipeline with Containerized Microservices

**This book is based on very old technology and the code behind it is not maintained anymore.**

