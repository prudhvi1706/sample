#!/bin/bash

rm -rf /usr/share/nginx/html/*
