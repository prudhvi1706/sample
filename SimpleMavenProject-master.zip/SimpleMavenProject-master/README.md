# SimpleMavenProject - for the Jenkins Primer Course
## We usually start with this project and build on it from here

* This is a simple project that uses Maven and Unit to test/compile/install a light weight Java package.

* When you check out this repo, you can `cd` into it and run one of the following:

`mvn clean`

`mvn test`

`mvn compile`

`mvn install`
 
* I normally use this project for demonstration purposes in my training courses!
