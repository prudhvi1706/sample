package nour;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ ArrayContainsTest.class, FormatTest.class, MergeIntArraysTest.class })
public class AllTests {

}
